#include <iostream>

int main() {

std::cout << "Test.\n";

}